//
//  ProjectConfigure.swift
//  华商领袖
//
//  Created by abc on 2019/4/2.
//  Copyright © 2019 huashanglingxiu. All rights reserved.
//

import Foundation

let kWX_APPID = "wx0a9ef3c6d7ed40c8"
let kWX_Secret = "a20339600c4f819de8f27c73fe512965"
