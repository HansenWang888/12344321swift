//
//  BaseModel.swift
//  华商领袖
//
//  Created by hansen on 2019/4/24.
//  Copyright © 2019 huashanglingxiu. All rights reserved.
//

import ObjectMapper

class BaseModel: Mappable {
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
    }
    
}
