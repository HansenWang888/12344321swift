//
//  NotificationDefine.swift
//  华商领袖
//
//  Created by abc on 2019/3/22.
//  Copyright © 2019 huashanglingxiu. All rights reserved.
//

import Foundation


public extension Notification.Name {
    
    static let nLogin_success = Notification.Name(rawValue: "Notification_login_success")
    static let nLogin_exit = Notification.Name(rawValue: "Notification_nLogin_exit")
    static let nUpdate_userInfo = Notification.Name(rawValue: "Update_userInfo")

    
}


