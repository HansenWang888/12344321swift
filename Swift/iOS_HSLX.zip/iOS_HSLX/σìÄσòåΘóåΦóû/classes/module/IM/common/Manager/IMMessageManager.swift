//
//  IMMessageManager.swift
//  TencentIM
//
//  Created by hansen on 2019/4/29.
//  Copyright © 2019 hansen. All rights reserved.
//

import UIKit

class IMMessageManager: NSObject {
    private override init() {
        super.init()
    }
    
    static let shared = IMMessageManager()
}
