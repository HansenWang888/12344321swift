//
//  ActivityManagerVC.swift
//  华商领袖
//
//  Created by hansen on 2019/5/16.
//  Copyright © 2019 huashanglingxiu. All rights reserved.
//

import UIKit

class ActivityManagerVC: BaseVC {

    var groupid:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "活动管理";
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
