//
//  IMConnectStatusView.swift
//  TencentIM
//
//  Created by hansen on 2019/4/30.
//  Copyright © 2019 hansen. All rights reserved.
//

import UIKit

class IMConnectStatusView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
