//
//  IMHomeCell.swift
//  华商领袖
//
//  Created by hansen on 2019/4/28.
//  Copyright © 2019 huashanglingxiu. All rights reserved.
//

import UIKit

class IMHomeCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
