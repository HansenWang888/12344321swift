//
//  NearbyDymanicModel.swift
//  华商领袖
//
//  Created by abc on 2019/4/8.
//  Copyright © 2019 huashanglingxiu. All rights reserved.
//

import ObjectMapper


class NearbyDymanicModel: Mappable {
    /*
     
     "comments": 5,
     "companyName": "6分",
     "content": "😁😁😁",
     "cpShortName": "",
     "createTime": 1546871949000,
     "distance": 38,
     "headUrl": "http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJgBPUT9bdWeTW5INdTLeagpW7gz2cWGnIPGChRAQc9ePzjeicRicFYFtrXRz3hGb87iczTl0uiaficxbA/132",
     "id": 85,
     "likeType": 0,
     "likes": 2,
     "location": "达美D6区",
     "name": "邓凯滔",
     "picture": "",
     "postName": "7秒",
     "publisherId": "610",
     "type": 0,
     "updateTime": 1553250281000
     }
     */
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        
    }
}
