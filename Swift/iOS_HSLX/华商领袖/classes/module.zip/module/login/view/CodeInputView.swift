//
//  CodeInputView.swift
//  华商领袖
//
//  Created by abc on 2019/3/22.
//  Copyright © 2019 huashanglingxiu. All rights reserved.
//

import UIKit

class CodeInputView: UIView {

    
    class func codeInputView(count: Int) {
        
        
//        for i in 0...count {
//
//            let view = UIView()
//            
//
//
//        }
        
        
        
        
        
    }
    
    
    

}
